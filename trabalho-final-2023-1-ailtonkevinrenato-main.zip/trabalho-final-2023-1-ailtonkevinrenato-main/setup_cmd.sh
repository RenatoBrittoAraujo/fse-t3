# run as sudo for accessing the device for flashing
sudo su

# setup terminal environment
. /home/renato/esp-idf/export.sh
