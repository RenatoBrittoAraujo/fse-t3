#ifndef SENSOR_DE_LUZ_H
#define SENSOR_DE_LUZ_H

void init_dispositivo_sensor_de_luz(int pin);

int captura_sensor_de_luz(int pin);

#endif