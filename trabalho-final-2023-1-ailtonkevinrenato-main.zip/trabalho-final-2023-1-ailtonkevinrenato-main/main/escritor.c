#include <stdio.h>

#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "driver/gpio.h"
#include "esp_log.h"
#include "sdkconfig.h"

#include "led_simples.h"
#include "dispositivos.h"
#include "escritor.h"
#include "led_simples.h"

static const char *TAG = "escritor";

int LAST_ID_ESCRITOR = 0;

Escritor create_escritor(Dispositivos *dispositivos)
{
    Escritor e;
    e.id_escritor = LAST_ID_ESCRITOR++;
    for (int i = 0; i <= NUM_DISPOSITIVOS; i++)
    {
        e.sensores_para_escrita[i] = 0;
    }

    // [TODO] add dispositivos escrita

    e.sensores_para_escrita[OUTPUT_LED_SIMPLES] = 1;
    e.sensores_para_escrita[OUTPUT_LED_RGB] = 1;
    e.sensores_para_escrita[OUTPUT_BUZZER] = 1;

    e.dispositivos = dispositivos;
    return e;
}

void init_escritor(Escritor *e)
{
    for (int i = 0; i <= NUM_DISPOSITIVOS; i++)
    {
        if (e->sensores_para_escrita[i] != 1)
            continue;
        init_dispositivo(e->dispositivos, i);
    }
}

Mensagem create_mensagem(Escritor *e)
{
    Mensagem m;
    m.escritor = e;
    return m;
}

void escreve_saidas(Mensagem *m)
{
    for (int i = 1; i <= NUM_DISPOSITIVOS; i++)
    {
        if (m->escritor->sensores_para_escrita[i] != 1)
            continue;
        int pin = get_pin(m->escritor->dispositivos, i);
        switch (i)
        {
        case OUTPUT_LED_SIMPLES:
            set_led_simples(pin, m->valor_led_simples);
            break;

        // [TODO] verificar kevin
        case OUTPUT_LED_RGB:
            gpio_set_level(19, m->valor_led_rgb_r);
            gpio_set_level(18, m->valor_led_rgb_g);
            gpio_set_level(5, m->valor_led_rgb_b);
            break;

        // [TODO] verificar ailton
        case OUTPUT_BUZZER:
            gpio_set_level(21, m->valor_buzzer);
            break;

        default:
            printf("[escritor] Dispositivo não encontrado\n");
            break;
        }
    }
}
