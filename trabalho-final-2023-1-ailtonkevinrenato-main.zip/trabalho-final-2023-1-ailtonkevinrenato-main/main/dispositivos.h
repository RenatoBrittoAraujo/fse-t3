#ifndef DISPOSITIVOS_H
#define DISPOSITIVOS_H

// É um rótulo pro dispositivo. tipo enum.
#define DISPOSITIVO_DESCONHECIDO 0
#define INPUT_DE_LUZ 1
#define INPUT_DHT11_TEMPERATURA_E_UMIDADE 2
#define INPUT_INVERMELHO 3
#define INPUT_DE_SOM 4
#define OUTPUT_LED_RGB 5
#define OUTPUT_LED_SIMPLES 6
#define OUTPUT_BUZZER 8
#define INPUT_DHT11_TEMPERATURA 9
#define INPUT_DHT11_UMIDADE 10

#define NUM_DISPOSITIVOS 10

// É um rótulo pro GPIO. tipo enum. não é o número da GPIO! quem define o numero da GPIO é o código.
#define GPIO_DESCONHECIDA 0
#define GPIO_INPUT_DE_LUZ 1
#define GPIO_INPUT_TEMPERATURA_E_UMIDADE 2
#define GPIO_INPUT_INVERMELHO 3
#define GPIO_INPUT_DE_SOM 4
#define GPIO_OUTPUT_LCD_RGB_R 5
#define GPIO_OUTPUT_LCD_RGB_G 6
#define GPIO_OUTPUT_LCD_RGB_B 7
#define GPIO_INPUT_DHT11 8
#define GPIO_OUTPUT_LED_SIMPLES 9
#define GPIO_OUTPUT_LED_RGB_R 10
#define GPIO_OUTPUT_LED_RGB_G 11
#define GPIO_OUTPUT_LED_RGB_B 12
#define GPIO_OUTPUT_BUZZER 13
#define GPIO_OUTPUT_LED_RGB_RED_GPIO 5
#define GPIO_OUTPUT_LED_RGB_GREEN_GPIO 18
#define GPIO_OUTPUT_LED_RGB_BLUE_GPIO 19

#define NUM_GPIOS 23

struct Dispositivos
{
    int gpio_pinout[NUM_GPIOS + 1];
    int dispositivos_ativos[NUM_DISPOSITIVOS + 1];
};
typedef struct Dispositivos Dispositivos;

Dispositivos create_config_dispositivos();
int get_pin(Dispositivos *d, int indx);
void init_dispositivo(Dispositivos *d, int i);

static const char *get_input_str(int num)
{
    switch (num)
    {
    case INPUT_INVERMELHO:
        return "INPUT_INVERMELHO";
case INPUT_DE_SOM:
        return "INPUT_DE_SOM";
    default:
        return "DISPOSITIVO_DESCONHECIDO";
    }
}

static const char *get_gpio_str(int pin)
{
    switch (pin)
    {
    case GPIO_INPUT_DE_LUZ:
        return "GPIO_INPUT_DE_LUZ";
    case GPIO_INPUT_TEMPERATURA_E_UMIDADE:
        return "GPIO_INPUT_TEMPERATURA_E_UMIDADE";
    case GPIO_INPUT_INVERMELHO:
        return "GPIO_INPUT_INVERMELHO";
    case GPIO_INPUT_DE_SOM:
        return "GPIO_INPUT_DE_SOM";
    case GPIO_INPUT_DHT11:
        return "GPIO_INPUT_DHT11";
    case GPIO_OUTPUT_BUZZER:
        return "GPIO_OUTPUT_BUZZER";
    default:
        return "GPIO_DESCONHECIDA";
    }
}

#endif