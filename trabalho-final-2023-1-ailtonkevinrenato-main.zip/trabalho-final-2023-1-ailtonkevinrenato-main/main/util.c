#include <sys/time.h>

#include "util.h"

int vec_i(int size, int curr, int indx)
{
    return (curr + indx) % size;
}

long get_time_ms()
{
    // printf("%s get_time_ms()\n", TAG);
    struct timeval tv;
    gettimeofday(&tv, NULL);
    return (tv.tv_sec * 1000LL + (tv.tv_usec / 1000LL));
}