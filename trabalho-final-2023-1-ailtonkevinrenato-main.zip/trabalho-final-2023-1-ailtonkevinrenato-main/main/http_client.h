#ifndef HTTP_CLIENT_H
#define HTTP_CLIENT_H

#include <inttypes.h>

void http_request();
void https_request();

#endif
