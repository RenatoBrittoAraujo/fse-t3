#ifndef SUBSISTEMA_DETECTOR_H
#define SUBSISTEMA_DETECTOR_H

#include "leitor.h"
#include "dispositivos.h"

struct Detector
{
    int min_tempo_calc_score;

    double min_desvios_padroes;
    double reset_score;
    double reset_release;
    double reset_val;
    double max_score_per_input;

    int size_old_scores;
    int max_size_old_scores;
    int index_old_scores;
    double old_scores[MAX_NUM_LEITURAS];

    double last_score;
    int is_evento_detectado;
    int detectores_ativos[NUM_DISPOSITIVOS + 1];
    double direcao;

    Leitor* leitor;
};
typedef struct Detector Detector;

Detector create_detector(Leitor *leitor);

void init_subsistema_detector(Detector *detector);

// apenas realiza o cálculo de detecção
void executar_deteccao(Detector *d, Sensores *leitura);

// limpa antigos calculos (para evitar qualquer problema)
void limpar_deteccao(Detector *d);

// retorna o resultado de deteção positiva ou não
int is_novo_evento_detectado(Detector *d);

// retorna os sensores que estão indicando uma mudança no ambiente
// tipo é int[NUM_DISPOSITIVOS + 1], limpe o pointeiro
int* get_detectores_ativos(Detector *d);

// retorna a direção da detecção (angulo de 0 a 360))
double get_direcao(Detector *d);

#endif