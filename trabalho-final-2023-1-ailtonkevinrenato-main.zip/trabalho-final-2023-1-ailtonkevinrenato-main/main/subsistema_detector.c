#include <math.h>
#include <stdio.h>
#include <math.h>
#include <stdint.h>
#include <unistd.h>

#include "infravermelho.h"
#include "leitor.h"
#include "subsistema_detector.h"
#include "dispositivos.h"
#include "util.h"

#define TAG "[subsistema_detector]"

// alocado estaticamente
double x[MAX_NUM_LEITURAS];
double novos_valores[NUM_DISPOSITIVOS + 1];

Detector create_detector(Leitor *leitor)
{
    Detector detector;
    detector.leitor = leitor;

    // periodo que nada será detectado (30 segundos)
    detector.min_tempo_calc_score = 30 * 1000;

    // desvios padrões do score para acusar detecção
    detector.min_desvios_padroes = 1;

    // fator que bloqueia novas detecções dentro de `reset_score` desvios padrões logo após uma detecção. Fator diminui `reset_release` unidades por tempo
    detector.reset_score = 5;
    detector.reset_release = 0.99;

    // valor de score máximo pro desvio padrão de cada um dos input
    detector.max_score_per_input = 8;

    detector.max_size_old_scores = MAX_NUM_LEITURAS;
    detector.size_old_scores = 0;
    detector.index_old_scores = 0;
    return detector;
}

void init_subsistema_detector(Detector *detector)
{
}

double calc_media(double *x, int n)
{
    // resultado indefinido
    if (n == 0)
        return 0;
    double soma = 0.0;
    for (int i = 0; i < n; i++)
    {
        soma += (double)x[i];
    }
    return soma / (double)n;
}

double calc_desvio_padrao(double *x, int n, double media)
{
    // resultado indefinido
    if (n == 0)
        return 0;
    double soma = 0;
    for (int i = 0; i < n; i++)
    {
        soma += ((double)x[i] - media) * ((double)x[i] - media);
    }
    return sqrt(soma / (double)n);
}

double get_desvios_padroes(double *x, int n, double y)
{
    double media = calc_media(x, n);
    double distancia_da_media = fabs(y - media);
    double desvio_padrao = calc_desvio_padrao(x, n, media);
    if (desvio_padrao != 0)
    {
        double desvios = distancia_da_media / desvio_padrao;
        return desvios;
    }
    return 0;
}

double get_deteccao_score(Detector *d)
{
    int n = d->leitor->size_old_leituras;
    double score = 0;
    double max_score = d->max_score_per_input * NUM_DISPOSITIVOS;

    for (int i = 1; i <= NUM_DISPOSITIVOS; i++)
    {
        if (n == 0)
        {
            return 0.0;
        }
        for (int j = 0; j < n; j++)
        {
            x[j] = d->leitor->old_leituras[j].valores[i];
        }
        double dv = get_desvios_padroes(x, n, novos_valores[i]);
        if (dv > d->max_score_per_input)
            dv = d->max_score_per_input;
        score += dv;
    }

    // força score a atender [0,1]
    score = score / max_score;
    return score;
}

void add_new_score(Detector *d, double score)
{
    int indx = vec_i(d->max_size_old_scores, d->size_old_scores, 0);
    if (d->size_old_scores < d->max_size_old_scores)
        d->size_old_scores += 1;
    d->index_old_scores += 1;
    d->index_old_scores %= d->max_size_old_scores;
    d->old_scores[indx] = score;
}

void executar_deteccao(Detector *d, Sensores *leitura)
{
    limpar_deteccao(d);

    int time_ms = get_time_ms();
    double dp_score = 0;

    // pegando os valores das leituras
    for (int i = 1; i <= NUM_DISPOSITIVOS; i++)
        novos_valores[i] = leitura->valores[i];

    double score = get_deteccao_score(d);
    add_new_score(d, score);
    d->last_score = score;
    printf("[subsistema_detector] \t\tSCORE: %lf\n", score);

    if (time_ms > d->min_tempo_calc_score)
    {
        dp_score = get_desvios_padroes(d->old_scores, d->size_old_scores, score);

        printf("[subsistema_detector]\t\tDESVIO PADRÃO: %lf\n", dp_score);

        if (dp_score > d->min_desvios_padroes && d->reset_val < dp_score)
        {
            d->is_evento_detectado = 1;
            d->reset_val = dp_score * d->reset_score;
        }
        d->reset_val *= d->reset_release;
    }
}

void limpar_deteccao(Detector *d)
{
    d->is_evento_detectado = 0;
    d->direcao = 0;
    d->last_score = 0;
    for (int i = 1; i <= NUM_DISPOSITIVOS; i++)
        d->detectores_ativos[i] = 0;
}

int is_novo_evento_detectado(Detector *d)
{
    int val = d->is_evento_detectado;
    return val;
}

// retorna os sensores que estão indicando uma mudança no ambiente
int *get_detectores_ativos(Detector *d)
{
    int *val = (int *)malloc(sizeof(int) * (NUM_DISPOSITIVOS + 1));
    val[0] = 0;
    for (int i = 1; i <= NUM_DISPOSITIVOS; i++)
        val[i] = d->detectores_ativos[i];
    return val;
}

// retorna a direção da detecção (angulo de 0 a 360))
double get_direcao(Detector *d)
{
    return d->direcao;
}