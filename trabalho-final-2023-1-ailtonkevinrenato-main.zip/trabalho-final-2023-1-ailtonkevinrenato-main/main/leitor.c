#include <stdio.h>

#include "nvs_flash.h"
#include "esp_wifi.h"
#include "esp_event.h"
#include "esp_http_client.h"
#include "esp_log.h"
#include "freertos/semphr.h"

#include "dispositivos.h"
#include "infravermelho.h"
#include "sensor_de_som.h"
#include "sensor_de_luz.h"
#include "leitor.h"
#include "dht11.h"

static const char *TAG = "[leitor]";

int LAST_ID_LEITOR = 0;

Leitor create_leitor(Dispositivos *dispositivos)
{
    Leitor l;

    l.id_leitor = LAST_ID_LEITOR++;

    // os últimos 2 minutos de leituras espaçados em 100ms cada
    l.max_old_leituras = MAX_NUM_LEITURAS;

    // periodo mínimo entre cada uma das leituras do sistema
    l.tempo_por_leitura = MIN_TEMPO_ENTRE_LEITURAS;

    l.dispositivos = dispositivos;

    l.max_size_old_leituras = l.max_old_leituras;
    l.size_old_leituras = 0;
    l.index_old_leituras = 0;

    for (int i = 0; i <= NUM_DISPOSITIVOS; i++)
        l.sensores_para_ler[i] = 0;

    // [TODO] Add dispositivos leitores

    l.sensores_para_ler[INPUT_DE_LUZ] = 1;
    l.sensores_para_ler[INPUT_DHT11_TEMPERATURA] = 1;
    l.sensores_para_ler[INPUT_DHT11_UMIDADE] = 1;
    l.sensores_para_ler[INPUT_DHT11_TEMPERATURA_E_UMIDADE] = 1;
    l.sensores_para_ler[INPUT_INVERMELHO] = 1;
    l.sensores_para_ler[INPUT_DE_SOM] = 1;

    l.last_leitura.valido = 0;

    return l;
}

void init_leitor(Leitor *l)
{
    printf("%s init_leitor()\n", TAG);
    fflush(NULL);
    for (int i = 1; i <= NUM_DISPOSITIVOS; i++)
    {
        if (!l->sensores_para_ler[i])
        {
            continue;
        }
        init_dispositivo(l->dispositivos, i);
    }
}

void registra_last_leitura(Leitor *l)
{
    if (!l->last_leitura.valido)
        return;

    l->old_leituras[l->index_old_leituras] = l->last_leitura;
    l->index_old_leituras = (l->index_old_leituras + 1) % l->max_old_leituras;
    if (l->size_old_leituras < l->max_size_old_leituras)
        l->size_old_leituras++;

    l->last_leitura.valido = 0;
}

Sensores le_sensores(Leitor *l)
{
    registra_last_leitura(l);

    for (int i = 1; i <= NUM_DISPOSITIVOS; i++)
    {
        if (!l->sensores_para_ler[i])
        {
            continue;
        }
        int pin = get_pin(l->dispositivos, i);

        if (i == INPUT_DE_LUZ)
            l->last_leitura.valores[INPUT_DE_LUZ] = captura_sensor_de_luz(pin);

        if (i == INPUT_DHT11_TEMPERATURA_E_UMIDADE)
        {
            // [TODO] kevin com faz pra ler?
            struct dht11_reading r = DHT11_read(pin);
            l->last_leitura.valores[INPUT_DHT11_TEMPERATURA] = r.temperature;
            l->last_leitura.valores[INPUT_DHT11_UMIDADE] = r.humidity;
        }

        if (i == INPUT_INVERMELHO)
            l->last_leitura.valores[INPUT_INVERMELHO] = captura_infravermelho(pin);

        if (i == INPUT_DE_SOM)
            l->last_leitura.valores[INPUT_DE_SOM] = captura_sensor_de_som(pin);
    }

    l->last_leitura.valido = 1;

    return l->last_leitura;
}
