#include <stdio.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "driver/gpio.h"
#include "esp_log.h"
#include "sdkconfig.h"

#include "sensor_de_luz.h"

static const char *TAG = "sensor_de_luz";

void init_dispositivo_sensor_de_luz(int pin)
{
    ESP_LOGD(TAG, "configurando sensor de luz na GPIO %d", pin);
    gpio_reset_pin(pin);
    gpio_set_direction(pin, GPIO_MODE_INPUT);
}

int captura_sensor_de_luz(int pin)
{
    int valor = gpio_get_level(pin);
    ESP_LOGD(TAG, "GPIO %d recebeu sensor de luz = %d", pin, valor);
    return valor;
}
