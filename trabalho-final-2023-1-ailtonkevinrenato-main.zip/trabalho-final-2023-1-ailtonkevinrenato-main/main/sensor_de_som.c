#include <stdio.h>

#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "driver/gpio.h"
#include "esp_log.h"
#include "sdkconfig.h"

#include "util.h"
#include "sensor_de_som.h"

static const char *TAG = "sensor_de_som";

#define TRIGGERED_FOR_MS 1000

int last_positive_timestamp = 0;

void IRAM_ATTR sensorISR(void *arg)
{
    last_positive_timestamp = get_time_ms();
}

void init_dispositivo_sensor_de_som(int pin)
{
    ESP_LOGD(TAG, "configurando sensor de som na GPIO %d", pin);
    gpio_reset_pin(pin);
    gpio_set_direction(pin, GPIO_MODE_INPUT);
    gpio_install_isr_service(ESP_INTR_FLAG_HIGH);
    gpio_isr_handler_add(pin, sensorISR, NULL);
}

int captura_sensor_de_som(int pin)
{
    if (last_positive_timestamp + TRIGGERED_FOR_MS > get_time_ms())
    {
        return 1;
    }
    int valor = gpio_get_level(pin);
    if (valor > 0)
    {
        last_positive_timestamp = get_time_ms();
        return 1;
    }
    return 0;
}
