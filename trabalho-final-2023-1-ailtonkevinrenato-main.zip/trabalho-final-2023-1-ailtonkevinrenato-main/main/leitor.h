#ifndef LEITOR_H
#define LEITOR_H

#include "dispositivos.h"
#include "infravermelho.h"
#include "sensor_de_som.h"

#define MAX_NUM_LEITURAS 100 // devia ser 1200, mas sem RAM
#define MIN_TEMPO_ENTRE_LEITURAS 100
#define LP_MIN_TEMPO_ENTRE_LEITURAS 200

struct Sensores
{
    int valido;

    float valores[NUM_DISPOSITIVOS + 1];
};
typedef struct Sensores Sensores;

struct Leitor
{
    int id_leitor;

    int max_old_leituras;
    int tempo_por_leitura;
    int min_tempo_calc_score;

    int sensores_para_ler[NUM_DISPOSITIVOS + 1];
    Dispositivos *dispositivos;

    int max_size_old_leituras;
    int size_old_leituras;
    int index_old_leituras;
    Sensores old_leituras[MAX_NUM_LEITURAS];

    Sensores last_leitura;
};
typedef struct Leitor Leitor;

Leitor create_leitor(Dispositivos *dispositivos);

void init_leitor(Leitor *l);

Sensores le_sensores(Leitor *l);

#endif