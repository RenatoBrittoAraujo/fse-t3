#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/time.h>

#include "freertos/FreeRTOS.h"
#include "driver/gpio.h"
#include "freertos/task.h"
#include "freertos/semphr.h"
#include "esp_log.h"
#include "nvs_flash.h"
#include "esp_wifi.h"
#include "esp_event.h"
#include "esp_http_client.h"
#include "rtc_wdt.h"
#include "esp_task_wdt.h"

// projeto
#include "dispositivos.h"
#include "leitor.h"
#include "escritor.h"
#include "subsistema_detector.h"
#include "wifi.h"
#include "mqtt.h"
#include "dht11.h"
#include "led_rgb.h"
#include "nvs.h"

#define PRINT_BOOL ? "true" : "false"

#define TAG_DETECTORES "[main_thread_detectores]"
#define TAG_TELEMETRIA "[main_thread_telemetria]"

#define BUZZER_PIN 21
#define GPIO_DHT11 22

#define MAIN_LOOP_DELAY_MS 100
#define TASK_WDT_TIMEOUT_MS 4000
#define PONTO_DELAY_MS 200
#define TRACO_DELAY_MS 600
#define ESPACO_DELAY_MS 400
#define WIFI_START_WAIT_MS 5000
#define MQTT_START_TIME_MS 5000
#define MQTT_SEND_TIME_MS 1000

#define LP_MAIN_LOOP_DELAY_MS 1000
#define LP_TASK_WDT_TIMEOUT_MS 10000
#define LP_PONTO_DELAY_MS 1000
#define LP_TRACO_DELAY_MS 2000
#define LP_ESPACO_DELAY_MS 1000
#define LP_WIFI_START_WAIT_MS 10000
#define LP_MQTT_START_TIME_MS 10000
#define LP_MQTT_SEND_TIME_MS 4000

#define LOW_POWER 0

Sensores sens;

int value = 0;

const char *codigoMorse[] = {
    ".-",   // a
    "-...", // b
    "-.-.", // c
    "-..",  // d
    ".",    // e
    "..-.", // f
    "--.",  // g
    "....", // h
    "..",   // i
    ".---", // j
    "-.-",  // k
    ".-..", // l
    "--",   // m
    "-.",   // n
    "---",  // o
    ".--.", // p
    "--.-", // q
    ".-.",  // r
    "...",  // s
    "-",    // t
    "..-",  // u
    "...-", // v
    ".--",  // w
    "-..-", // x
    "-.--", // y
    "--.."  // z
};

void ativarLedVermelho()
{
  gpio_set_level(GPIO_NUM_5, 0);
  gpio_set_level(GPIO_NUM_18, 0);
  gpio_set_level(GPIO_NUM_19, 1);
}

void ativarLedVerde()
{
  gpio_set_level(GPIO_NUM_5, 0);
  gpio_set_level(GPIO_NUM_18, 1);
  gpio_set_level(GPIO_NUM_19, 0);
}

void ativarBuzzer()
{
  gpio_set_level(BUZZER_PIN, 1); // Define o pino do buzzer como nível alto (ativa o buzzer)
}

void desativarBuzzer()
{
  gpio_set_level(BUZZER_PIN, 0); // Define o pino do buzzer como nível baixo (desativa o buzzer)
}

void emitirSinal(int delay)
{
  ativarBuzzer();
  vTaskDelay(delay / portTICK_PERIOD_MS);
  desativarBuzzer();
  vTaskDelay((LOW_POWER ? LP_ESPACO_DELAY_MS : ESPACO_DELAY_MS) / portTICK_PERIOD_MS);
}

SemaphoreHandle_t conexaoWifiSemaphore;
SemaphoreHandle_t conexaoMQTTSemaphore;

void codigo_morse(const char *mensagem)
{
  for (int i = 0; mensagem[i]; i++)
  {
    char c = tolower(mensagem[i]);
    if (c >= 'a' && c <= 'z')
    {
      const char *padrao = codigoMorse[c - 'a'];
      for (int j = 0; padrao[j]; j++)
      {
        if (padrao[j] == '.')
        {
          emitirSinal(LOW_POWER ? LP_PONTO_DELAY_MS : PONTO_DELAY_MS);
        }
        else if (padrao[j] == '-')
        {
          emitirSinal(LOW_POWER ? LP_TRACO_DELAY_MS : TRACO_DELAY_MS);
        }
      }
    }
  }
}

void thread_detectores(void *params)
{
  printf("[main_thread_detectores] inicia detectores\n");

  printf("[main_thread_detectores] Criando dispositivos\n");
  Dispositivos dispositivos = create_config_dispositivos();

  printf("[main_thread_detectores] Criando leitor com %d memorias\n", MAX_NUM_LEITURAS);
  Leitor leitor = create_leitor(&dispositivos);

  printf("[main_thread_detectores] Criando escritor\n");
  Escritor escritor = create_escritor(&dispositivos);

  printf("[main_thread_detectores] Criando detector com %d memorias de score\n", MAX_NUM_LEITURAS);
  Detector detector = create_detector(&leitor);

  printf("[main_thread_detectores] Iniciando leitor\n");
  init_leitor(&leitor);

  printf("[main_thread_detectores] Iniciando escritor\n");
  init_escritor(&escritor);

  printf("[main_thread_detectores] Iniciando detector\n");
  init_subsistema_detector(&detector);

  limpar_deteccao(&detector);

  printf("[main_thread_detectores] Iniciando loop principal\n");
  int deteccao_bounce = 0;
  while (1)
  {
    Sensores leitura = le_sensores(&leitor);
    sens = leitura;

    printf("[main_thread_detectores] INFRAVERMELHO = %.0lf\n", leitura.valores[INPUT_INVERMELHO]);
    printf("[main_thread_detectores] SOM           = %.0lf\n", leitura.valores[INPUT_DE_SOM]);
    printf("[main_thread_detectores] LUZ           = %.0lf\n", leitura.valores[INPUT_DE_LUZ]);
    printf("[main_thread_detectores] TEMPERATURA   = %.0lf\n", leitura.valores[INPUT_DHT11_TEMPERATURA]);
    printf("[main_thread_detectores] HUMILDADE     = %.0lf\n", leitura.valores[INPUT_DHT11_UMIDADE]);

    executar_deteccao(&detector, &leitura);
    Mensagem msg = create_mensagem(&escritor);

    if (is_novo_evento_detectado(&detector))
    {
      printf("[main_thread_detectores] NOVO EVENTO FOI DETECTADO\n");

      // manda do thingsboard

      msg.valor_led_simples = 1;
      msg.valor_led_rgb_r = 1;
      msg.valor_led_rgb_g = 0;
      msg.valor_led_rgb_b = 0;
      msg.valor_buzzer = 1;
      deteccao_bounce = 10;
    }
    else if (deteccao_bounce < 1)
    {
      msg.valor_led_simples = 0;
      msg.valor_led_rgb_r = 0;
      msg.valor_led_rgb_g = 0;
      msg.valor_led_rgb_b = 1;
      msg.valor_buzzer = 0;
    }
    deteccao_bounce--;

    escreve_saidas(&msg);

    vTaskDelay((LOW_POWER ? LP_MIN_TEMPO_ENTRE_LEITURAS : MIN_TEMPO_ENTRE_LEITURAS) / portTICK_PERIOD_MS);
  }
}

void conectadoWifi(void *params)
{
  wifi_start();
  while (true)
  {
    if (xSemaphoreTake(conexaoWifiSemaphore, portMAX_DELAY))
    {

      const char *msg = "wifi";
      // codigo_morse(msg);
      vTaskDelay((LOW_POWER ? LP_WIFI_START_WAIT_MS : WIFI_START_WAIT_MS) / portTICK_PERIOD_MS);

      // Processamento Internet
      mqtt_start();
    }
  }
}

void thread_telemetria(void *params)
{
  print_values();
  
  char mensagem[200];
  char jsonAtributos[200];
  int cont = le_valor_nvs("contador");

  if (xSemaphoreTake(conexaoMQTTSemaphore, portMAX_DELAY))
  {
    const char *msg = "mqtt";
    // codigo_morse(msg);
    vTaskDelay((LOW_POWER ? LP_MQTT_START_TIME_MS : MQTT_START_TIME_MS) / portTICK_PERIOD_MS);


    int temperatura = 0;
    int umidade = 0;
    bool todos = false;
    while (true)
    {
      double sensor_de_luz = sens.valores[INPUT_DE_LUZ];
      double sensor_de_som = sens.valores[INPUT_DE_SOM];
      double infravermelho = sens.valores[INPUT_INVERMELHO];
      double temperatura = sens.valores[INPUT_DHT11_TEMPERATURA];
      double umidade = sens.valores[INPUT_DHT11_UMIDADE];

      sprintf(mensagem, "{\"temperatura\": %.2f, \"umidade\": %.2f, \"infravermelho\": %.2f, \"sensor_de_som\": %.2f, \"sensor_de_luz\": %.2f}", temperatura, umidade, infravermelho, sensor_de_som, sensor_de_luz);

      mqtt_envia_mensagem("v1/devices/me/telemetry", mensagem);

      sprintf(jsonAtributos, "{\"quantidade\": %d}", cont);
      mqtt_envia_mensagem("v1/devices/me/attributes", jsonAtributos);

      vTaskDelay((LOW_POWER ? LP_MQTT_SEND_TIME_MS : MQTT_SEND_TIME_MS) / portTICK_PERIOD_MS);
      printf("Grava valor contador: %d\n", grava_valor_nvs(cont, "contador"));
      printf("Grava valor temperatura: %d\n", grava_valor_nvs(temperatura, "temperatura"));
      printf("Grava valor umidade: %d\n", grava_valor_nvs(umidade, "umidade"));

      vTaskDelay((LOW_POWER ? LP_MQTT_SEND_TIME_MS : MQTT_SEND_TIME_MS) / portTICK_PERIOD_MS);
      cont++;
      if (get_botao_ligado())
      {
        ativarBuzzer();
        ativarLedVermelho();
      }
      else
      {
        desativarBuzzer();
        ativarLedVerde();
      }
    }
  }
}

void app_main(void)
{
 
  // Inicializa os semáforos
  conexaoWifiSemaphore = xSemaphoreCreateBinary();
  conexaoMQTTSemaphore = xSemaphoreCreateBinary();

  esp_err_t ret = nvs_flash_init();
  if (ret == ESP_ERR_NVS_NO_FREE_PAGES || ret == ESP_ERR_NVS_NEW_VERSION_FOUND)
  {
    ESP_ERROR_CHECK(nvs_flash_erase());
    ret = nvs_flash_init();
  }

  ESP_ERROR_CHECK(ret);

  ESP_LOGI("MAIN", "Iniciando threads");

  xTaskCreate(&thread_detectores, "task_detectores", 100000, NULL, 1, NULL);

  xTaskCreate(&conectadoWifi, "task_conexao_com_mqtt", 4096, NULL, 1, NULL);

  xTaskCreate(&thread_telemetria, "task_comunicacao_com_brokers", 4096, NULL, 1, NULL);
}