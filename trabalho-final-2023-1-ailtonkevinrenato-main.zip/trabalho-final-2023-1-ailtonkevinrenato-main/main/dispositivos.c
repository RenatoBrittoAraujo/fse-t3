#include <stdio.h>

#include "dispositivos.h"

#include "led_simples.h"
#include "infravermelho.h"
#include "sensor_de_som.h"
#include "sensor_de_luz.h"
#include "led_rgb.h"
#include "dht11.h"

Dispositivos create_config_dispositivos()
{
    Dispositivos dispositivos;

    for (int i = 0; i <= NUM_DISPOSITIVOS; i++)
        dispositivos.dispositivos_ativos[i] = 1;

    // [TODO?] configurando dispositivos
    dispositivos.dispositivos_ativos[INPUT_INVERMELHO] = 1;

    for (int i = 0; i <= NUM_GPIOS; i++)
        dispositivos.gpio_pinout[i] = 0;

    // configurando GPIOS

    // RENATO:
    // [TODO] VERIFICA
    dispositivos.gpio_pinout[GPIO_INPUT_INVERMELHO] = 33;
    dispositivos.gpio_pinout[GPIO_INPUT_DE_SOM] = 25;
    dispositivos.gpio_pinout[GPIO_INPUT_DE_LUZ] = 26;
    dispositivos.gpio_pinout[GPIO_OUTPUT_LED_SIMPLES] = 23;
    dispositivos.gpio_pinout[GPIO_INPUT_DHT11] = 22;

    // AILTON:
    // [TODO] VERIFICA
    dispositivos.gpio_pinout[GPIO_OUTPUT_BUZZER] = 21;

    // KEVIN: 5 18 19
    // [TODO] VERIFICA
    dispositivos.gpio_pinout[GPIO_INPUT_DHT11] = 22;
    dispositivos.gpio_pinout[GPIO_OUTPUT_LCD_RGB_R] = 5;
    dispositivos.gpio_pinout[GPIO_OUTPUT_LCD_RGB_G] = 18;
    dispositivos.gpio_pinout[GPIO_OUTPUT_LCD_RGB_B] = 19;

    return dispositivos;
}

int get_pin(Dispositivos *d, int indx)
{
    // printf("[get_pin] get_pin(indx=%d)\n", indx);

    if (indx == INPUT_DHT11_TEMPERATURA_E_UMIDADE)
        return d->gpio_pinout[GPIO_INPUT_DHT11];

    if (indx == INPUT_DE_LUZ)
        return d->gpio_pinout[GPIO_INPUT_DE_LUZ];

    if (indx == INPUT_DE_SOM)
        return d->gpio_pinout[GPIO_INPUT_DE_SOM];

    if (indx == INPUT_DHT11_TEMPERATURA_E_UMIDADE || indx == INPUT_DHT11_UMIDADE || indx == INPUT_DHT11_TEMPERATURA)
        return d->gpio_pinout[GPIO_INPUT_DHT11];

    if (indx == INPUT_INVERMELHO)
        return d->gpio_pinout[GPIO_INPUT_INVERMELHO];

    if (indx == OUTPUT_LED_SIMPLES)
        return d->gpio_pinout[GPIO_OUTPUT_LED_SIMPLES];

    if (indx == OUTPUT_LED_RGB)
        return d->gpio_pinout[GPIO_OUTPUT_LED_RGB_R];

    if (indx == OUTPUT_BUZZER)
        return d->gpio_pinout[GPIO_OUTPUT_BUZZER];

    printf("[dispositivos] ERRO! nenhum pin encontrado para input: %d\n", indx);
    printf("ERRO! A lista de pinos é esta:\n");

    for (int i = 1; i <= NUM_GPIOS; i++)
        if (d->gpio_pinout[i] != -1)
            printf("GPIO PINO %s ESTÁ ATIVO", get_gpio_str(i));

    return 0;
}

void init_dispositivo(Dispositivos *d, int i)
{
    int pin = get_pin(d, i);

    // printf("[dispositivos] init_dispostivo (device=%d pin=%d)\n", i, pin);

    if (i == INPUT_DE_LUZ)
        init_dispositivo_sensor_de_luz(pin);

    if (i == INPUT_DE_SOM)
        init_dispositivo_sensor_de_som(pin);

    if (i == INPUT_DHT11_TEMPERATURA_E_UMIDADE)
    {
        DHT11_init(pin);
    }
    // init_dispositivo_TEMPERATURA_e_umidade(pin);

    if (i == INPUT_INVERMELHO)
        init_dispositivo_infravermelho(pin);

    if (i == OUTPUT_LED_RGB)
    {
        init_dispositivo_led_rbg(0);
    }

    if (i == OUTPUT_LED_SIMPLES)
    {
        init_dispositivo_led_simples(pin);
    }

    if (i == OUTPUT_BUZZER)
    {
        gpio_reset_pin(21);
        gpio_set_direction(21, GPIO_MODE_OUTPUT);
    }
}
