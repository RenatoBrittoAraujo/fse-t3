#ifndef CONN_WIFI_H
#define CONN_WIFI_H

void RealizaHTTPRequest(void *params);
void conn_wifi(void);

#endif
