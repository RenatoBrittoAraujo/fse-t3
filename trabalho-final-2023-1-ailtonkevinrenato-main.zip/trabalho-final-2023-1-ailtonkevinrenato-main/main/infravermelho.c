#include <stdio.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "driver/gpio.h"
#include "esp_log.h"
#include "sdkconfig.h"

#include "infravermelho.h"

static const char *TAG = "infravermelho";

void init_dispositivo_infravermelho(int pin)
{

    printf("%s configurando como input na gpio %d\n", TAG, pin);
    gpio_set_direction(pin, GPIO_MODE_INPUT);
    printf("%s configurado com sucesso\n", TAG);
}

// varia entre 0 e 1
int captura_infravermelho(int pin)
{
    int infravemelho_level = gpio_get_level(pin);
    return infravemelho_level;
}
