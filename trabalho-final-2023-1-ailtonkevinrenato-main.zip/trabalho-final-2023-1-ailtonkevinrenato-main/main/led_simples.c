#include <stdio.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "driver/gpio.h"
#include "esp_log.h"
#include "sdkconfig.h"

#include "led_simples.h"

static const char *TAG = "led_simples";

void init_dispositivo_led_simples(int pin)
{
    ESP_LOGD(TAG, "configurando led simples na GPIO %d", pin);
    gpio_reset_pin(pin);
    gpio_set_direction(pin, GPIO_MODE_OUTPUT);
}

void set_led_simples(int pin, int valor)
{
    ESP_LOGD(TAG, "GPIO %d setou led simples para: %d", pin, valor);
    gpio_set_level(pin, valor);
}
