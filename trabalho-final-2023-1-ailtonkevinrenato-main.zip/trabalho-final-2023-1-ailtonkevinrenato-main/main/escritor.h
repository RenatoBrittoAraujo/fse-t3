#ifndef ESCRITOR_H
#define ESCRITOR_H

#include "dispositivos.h"

struct Escritor
{
    int id_escritor;

    int sensores_para_escrita[NUM_DISPOSITIVOS + 1];

    Dispositivos *dispositivos;
};
typedef struct Escritor Escritor;

struct Mensagem
{
    Escritor *escritor;

    int valor_led_simples;
    int valor_led_rgb_r;
    int valor_led_rgb_g;
    int valor_led_rgb_b;
    int valor_buzzer;
};
typedef struct Mensagem Mensagem;

Escritor create_escritor(Dispositivos *dispositivos);

void init_escritor(Escritor *e);

Mensagem create_mensagem(Escritor *e);

void escreve_saidas(Mensagem *m);

#endif