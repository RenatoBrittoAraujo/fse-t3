#ifndef LED_RGB_H
#define LED_RGB_H

#include <stdio.h>

void init_dispositivo_led_rbg(int pin);

void set_rgb_color(uint8_t red, uint8_t green, uint8_t blue);

#endif
