#ifndef SENSOR_DE_SOM_H
#define SENSOR_DE_SOM_H

void init_dispositivo_sensor_de_som(int pin);

int captura_sensor_de_som(int pin);

#endif