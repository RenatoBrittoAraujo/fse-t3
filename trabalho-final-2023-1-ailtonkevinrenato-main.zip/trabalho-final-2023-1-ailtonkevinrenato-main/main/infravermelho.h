#ifndef INFRAVERMELHO_H
#define INFRAVERMELHO_H

void init_dispositivo_infravermelho(int pin);

int captura_infravermelho(int pin);

#endif