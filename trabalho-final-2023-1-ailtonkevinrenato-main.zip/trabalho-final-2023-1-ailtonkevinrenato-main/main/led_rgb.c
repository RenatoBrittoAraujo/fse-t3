#include <stdio.h>
#include "driver/gpio.h"
#include "esp_log.h"
#include "freertos/FreeRTOS.h"

#include "led_rgb.h"

static const char *TAG = "LED_RGB";

#define PIN_RED 19   // GIOP5
#define PIN_GREEN 18 // GIOP18
#define PIN_BLUE 5   // GIOP19

void init_dispositivo_led_rbg(int pin)
{
    ESP_LOGI(TAG, "configurando na GPIO %d %d %d", PIN_RED, PIN_GREEN, PIN_BLUE);

    gpio_reset_pin(PIN_RED);
    gpio_set_direction(PIN_RED, GPIO_MODE_OUTPUT);

    gpio_reset_pin(PIN_GREEN);
    gpio_set_direction(PIN_GREEN, GPIO_MODE_OUTPUT);

    gpio_reset_pin(PIN_BLUE);
    gpio_set_direction(PIN_BLUE, GPIO_MODE_OUTPUT);
}

void set_rgb_color(uint8_t red, uint8_t green, uint8_t blue)
{
    // Definir os níveis lógicos dos pinos para controlar a cor
    gpio_set_level(PIN_RED, red);
    gpio_set_level(PIN_GREEN, green);
    gpio_set_level(PIN_BLUE, blue);
}