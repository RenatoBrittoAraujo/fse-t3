#ifndef UTIL_H
#define UTIL_H

int vec_i(int size, int curr, int indx);

long get_time_ms();

#endif