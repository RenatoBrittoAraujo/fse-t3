#ifndef NVS_H
#define NVS_H

#include <stdint.h>

int le_valor_nvs(char *chave);
int grava_valor_nvs(int32_t valor, char *grava_valor_nvs);
void print_values();
#endif // NVS_H
