# Notas

- Sensor digital é ler por GPIO o dado já "mastigado"

# Filosofia do código e lições apredidas:

- Injeção de dependências
  - Tudo é instanciado na main
  - Tudo que não for instanciado na main DEVE gerenciar todo o ciclo de vida de seus objetos.
- Evitar usar pointeiros
  - Só causa problema, e não dá vantagem muitas vezes se você souber modelar bem

# Sobre o sistema detector

Vamos descrever o fenômeno de deteção da seguinte forma: como linhas em um gráfico `s = f(t)` onde
`s` é o valor do detector entre `[0,1]` (divide pela sua variação máxima) e `t` é tempo. Demonstrado abaixo:

![](imgs/grafico_s_t_descr.jpg)

Vamos demonstrar como esse gráfico funcionaria em um exemplo. Existem 3 sensores, um com linha contínua, outro com a linha tracejada e um terceiro com a linha pontilhada:

![](imgs/grafico_s_t_exemplo.jpg)

- Linha contínua: detector que varia bastante de forma contínua.
- Linha tracejada: detector discreto que tem uma resolução de leituras baixa.
- Linha pontilhada: detector discreto com um bounce.

Uma forma de se determinar que um evento novo foi detectado pelos sensores seria ao tentar fazer uma ponderação da leitura atual pelo desvio padrão da média das leituras anteriores. 

Isso elimina problemas como o bounce (no segundo bounce, o desvio padrão daquela leitura será menor do que da primeira), elimina erros no leitor contínuo e permite que o modelo do leitor discreto com baixa resolução seja tratado com maior intensidade quando muda de estado.  

Para testar essa ideia, o código no `tests/desvio_padrao.py` foi criado. Observe:

![](imgs/valores_test_102_dp.png)

Esse é um output do código, simulando os outputs de sensores ao longo do tempo. Neste código temos 3 sensores `v1`, `v2` e `v3`. V1 é uma função de tangente. V2 e V3 são funções discretas que variam aleatoriamente.

Baseado nessas 3 funções, vamos tentar detectar mudanças no ambiente:

![](imgs/reultados_test_102_dp.png)

A linha laranja são as detecções. Note como apenas variações grandes de valor `v1`, `v2` e `v3` fazem com que o evento seja detectado. 

A todo momento após um certo tempo de execução dos sensores, um `score` está sendo calculado, que é a soma dos desvios padrões das variações nos inputs.

Quando o desvio padrão da própria função de scores ultrapassa um certo valor mínimo, um novo input é dito detectado.

Veja mais exemplos desse algoritmo:

![](imgs/test_101_dp.png)
![](imgs/test_103_dp.png)
![](imgs/test_104_dp.png)
![](imgs/test_105_dp.png)

Essa solução proposta parece atender suficientemente bem a necessidade do sistema pois:
- pode ser "tunada" como mais neurótica ou menos (reagir mais às entradas ou menos).
- permite uma quantidade arbitrária de inputs.
- visualmente, como mostrado acima, parece bastante coerente com as entradas.

Constantes de ajuste (nome = valor padrão):
- tempo_por_sample = 100 milissegundos
  - Periodo de tempo entre cada medida de sensores
- min_tempo_calc_score = 30 segundos 
  - Periodo de tempo minimo para sistema acusar detecção
- min_desvios_padroes = 1 desvio padrão
  - Desvios padrões do score para acusar detecção
- reset_score, reset_release = 5, 0.99
  - Fator que bloqueia novas detecções dentro de `reset_score` desvios padrões logo após uma detecção. Fator diminui `reset_release` unidades por tempo
- historico_tempo = 120 segundos
  - o sistema lembra do que aconteceu nos ultimos `historico_tempo` segundos para calcular a média e desvio padrão baseado no passado.

# Infravermelho
# [IMPLEMENTADO] Infravermelho

Nome: HC-SR501 Passive Infrared Sensor (PIR sensor)

- https://mschoeffler.com/2021/05/15/arduino-tutorial-hc-sr501-passive-infrared-sensor-pir-sensor/
- https://components101.com/sensors/hc-sr501-pir-sensor
- https://fritzing.org/projects/hc-sr501-passive-infrared-sensor-pir

# Sensor de som

Acho que é esse aqui
https://blogmasterwalkershop.com.br/arduino/como-usar-com-arduino-sensor-detector-de-som-ky-038

Mas pode também ser esse aqui:
https://blog.eletrogate.com/modulo-sensor-de-som-descricao-e-aplicacoes/

# Sensor foto resistor LDR

https://portal.vidadesilicio.com.br/sensor-de-luz-com-ldr/


