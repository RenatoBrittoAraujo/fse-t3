#include <stdio.h>
#include <stdint.h>
#include <sys/time.h>
#include <unistd.h>



int main()
{
    long start = get_time_ms();
    printf("%ld\n", start);
    // int x[10];
    // x[2] = 1;
    // x[1] = 0;

    // x[2] &= 1;
    // x[1] &= 1;

    sleep(1);

    // printf("x[1] = %ld | x[2] = %ld\n", x[1], x[2]);
    long end = get_time_ms();
    printf("after %ld\n", end);

    printf("time diff: %ld\n", end - start);
}