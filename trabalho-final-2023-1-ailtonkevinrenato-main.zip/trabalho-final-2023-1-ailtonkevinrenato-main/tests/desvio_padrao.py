import math
import random
import time

from matplotlib import pyplot as plt

tempo_por_sample = 100  # ms
min_tempo_calc_score = 30*1000  # ms
tempo_total_programa = 10*60*1000  # ms

MIN_DESVIOS_PADROES = 1
RESET_SCORE = 5
RESET_RELEASE = 0.99

# tamanho do vetor de historico
historico_tempo = 2*60*1000  # lembra do que aconteceu nos ultimos 2 minutos
historico_size = historico_tempo / tempo_por_sample

# quantidade de vezes que inputs serao gerados para cada
# tamanho do vetor de historico historico_size
RESOLUCAO = 30

# numero de detectores
max_score_per_input = 1

# ignore
periodov2 = 2200
periodov3 = 2400


def v1(t):
    # continuo
    tg = math.tan(t/10000)**2 + 10
    tg = 1000/max(1, tg)
    tg = tg**2

    tg = max(tg, 0)
    tg = min(tg, 100)
    tg = tg / 100
    return tg


def v2(t):
    global last
    if t % periodov2 == 0:
        if random.randint(0, periodov2) > periodov2/2:
            return last
        last += (0.5 - random.random())*random.random()*random.random()*3.0
        last = max(0.0, min(1.0, last))
        return last
    return last


def v3(t):
    global last2
    if t % periodov3 == 0:
        if random.randint(0, periodov2) > periodov2/2:
            return last2
        last2 += (0.5 - random.random())*random.random()*2.0
        last2 = max(0.0, min(1.0, last2))
        return last2
    return last2


def calc_media(lista):
    if len(lista) == 0:
        return 0
    return sum(lista) / len(lista)


def calc_desvio_padrao(lista):
    if len(lista) - 1 == 0:
        return 0
    media = calc_media(lista)
    soma = 0
    for i in lista:
        soma += (i - media) ** 2

    return math.sqrt(soma / (len(lista) - 1))


def get_desvios_padroes(valores, novo_valor, cutoff=1):
    distancia_da_media = math.fabs(novo_valor - calc_media(valores))
    desvio_padrao = calc_desvio_padrao(valores)

    if desvio_padrao != 0:
        desvios = distancia_da_media / desvio_padrao
        return desvios

    # não da pra calcular, ignorado com valor neutro
    return 0


def get_deteccao_score(t, historicos, novos_valores, cutoff=1):
    score = 0

    if len(historicos) != len(novos_valores):
        raise Exception(
            "tamanho de historicos e novos_valores devem ser iguais")

    num_inputs = len(novos_valores)

    out = {}

    for i in range(num_inputs):
        out[i] = get_desvios_padroes(historicos[i], novos_valores[i], cutoff)
        if out[i] > max_score_per_input:
            out[i] = max_score_per_input
        score += out[i]

    score = score / (max_score_per_input*num_inputs)

    return score


def test_desvio_padrao():
    global last, last2
    last2 = 1
    last = 0

    i = 0

    lastv1 = []
    lastv2 = []
    lastv3 = []
    last_scores = []

    tempo_historico = []
    v1_historico = []
    v2_historico = []
    v3_historico = []
    score_historico = []
    evento_historico = []
    release_historico = []
    score_dv_historico = []

    eventos_detectados = 0
    reset_val = 0

    while True:
        t = i*tempo_por_sample

        if tempo_total_programa <= t:
            break

        tempo_historico.append(t/1000)

        val1 = v1(t)
        val2 = v2(t)
        val3 = v3(t)

        v1_historico.append(val1)
        v2_historico.append(val2)
        v3_historico.append(val3)

        lastv1.append(val1)
        lastv2.append(val2)
        lastv3.append(val3)

        if len(lastv1) > historico_size:
            lastv1.pop(0)

        if len(lastv2) > historico_size:
            lastv2.pop(0)

        if len(lastv3) > historico_size:
            lastv3.pop(0)

        dp_score = 0
        evento_detectado = False
        score = get_deteccao_score(
            t, [lastv1, lastv2, lastv3], [val1, val2, val3])

        last_scores.append(score)
        if len(last_scores) > historico_size:
            last_scores.pop(0)

        if t > min_tempo_calc_score:
            dp_score = get_desvios_padroes(last_scores, score)

            if dp_score > MIN_DESVIOS_PADROES and reset_val < dp_score:
                evento_detectado = True
                reset_val = dp_score*RESET_SCORE

            reset_val *= RESET_RELEASE

        if evento_detectado:
            eventos_detectados += 1

        score_historico.append(score)
        evento_historico.append(1 if evento_detectado else 0)
        score_dv_historico.append(dp_score)
        release_historico.append(reset_val)

        i += 1

    return {
        "tempo": tempo_historico,
        "v1": v1_historico,
        "v2": v2_historico,
        "v3": v3_historico,
        "score": score_historico,
        "evento": evento_historico,
        "release": release_historico,
        "score_dv": score_dv_historico,
        "eventos_detectados": eventos_detectados,
    }


seeds = [
    100,
    # 101,
    # 102,
    # 103,
    # 104
]
if __name__ == "__main__":
    for seed in seeds:
        random.seed(seed)

        res = test_desvio_padrao()

        print("eventos detectados:", res["eventos_detectados"])

        tempo = res["tempo"]

        # PLOTA OS RESULTADOS
        plt.xlabel('Segundos')
        plt.figure(figsize=(10, 5), dpi=200)

        plt.plot(tempo, res["v1"], label="v1")
        plt.plot(tempo, res["v2"], label="v2")
        plt.plot(tempo, res["v3"], label="v2")
        # plt.savefig(fname=f"../imgs/valores_test_{seed}_dp.png")

        # PLOTA OS RESULTADOS
        plt.xlabel('Segundos')
        mx = max(res["score_dv"])
        evento = [e*mx for e in res["evento"]]
        score_mx = mx / max(res["score"])
        score = [e*score_mx for e in res["score"]]
        plt.plot(tempo, score, label="score")
        plt.plot(tempo, evento, label="evento")
        # plt.plot(tempo, res["release"], label="release")
        plt.plot(tempo, res["score_dv"], label="score_dv")
        # plt.savefig(fname=f"../imgs/reultados_test_{seed}_dp.png")
        plt.legend()
        # plt.clf()

        plt.show()

        # # PLOTA OS DOIS EM UMA IMAGEM
        # plt.figure(figsize=(10, 5), dpi=200)
        # plt.xlabel('Segundos')
        # plt.subplot(2, 1, 1)
        # plt.plot(tempo, res["v1"], label="v1")
        # plt.plot(tempo, res["v2"], label="v2")
        # plt.plot(tempo, res["v3"], label="v3")
        # plt.legend()

        # plt.subplot(2, 1, 2)
        # mx = max(res["score_dv"])
        # evento = [e*mx for e in res["evento"]]
        # score_mx = mx / max(res["score"])
        # score = [e*score_mx for e in res["score"]]
        # plt.plot(tempo, score, label="score")
        # plt.plot(tempo, evento, label="evento")
        # # plt.plot(tempo, res["release"], label="release")
        # plt.plot(tempo, res["score_dv"], label="score_dv")
        # plt.legend()

        # plt.savefig(fname=f"../imgs/test_{seed}_dp.png")

        # # plt.axes()

        # # plt.ylim(0,1)
        # plt.clf()
        # plt.show()

        # plt.show()
